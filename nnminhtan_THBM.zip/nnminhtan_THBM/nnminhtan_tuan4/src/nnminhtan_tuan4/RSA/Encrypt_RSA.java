/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nnminhtan_tuan4.RSA;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.nio.Buffer;
import java.security.interfaces.RSAPublicKey;

/**
 *
 * @author Administrator
 */
public class Encrypt_RSA {
    public static void main() throws Exception{
//        FileInputStream fm = new FileInputStream("M:\\Message.txt");
//        ObjectInputStream bm = new ObjectInputStream(fm);
//        String s = bm.toString();
//        
//        FileInputStream f = new FileInputStream("M:\\Dkry_RSA_pub.txt");
//        ObjectInputStream b = new ObjectInputStream(f);
//        RSAPublicKey pbk = (RSAPublicKey)b.readObject();
//        BigInteger e = pbk.getPublicExponent();
//        BigInteger n = pbk.getModulus();
//        System.out.println("e= "+e);
//        System.out.println("n= "+n);
//        byte ptext[] = s.getBytes("UTF8");
//        BigInteger m = new BigInteger(ptext);
//        BigInteger c = m.modPow(e, n);
//        System.out.println("c= "+c);
//        String cs = c.toString();
//        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
//                new FileOutputStream("M:\\Enc_RSA.txt")));
//        out.write(cs,0,cs.length());
//        out.close();
        
    }
}
